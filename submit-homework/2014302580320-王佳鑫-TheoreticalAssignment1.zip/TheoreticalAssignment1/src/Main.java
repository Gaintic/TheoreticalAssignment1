
import java.io.IOException;

public class Main {

	
	public static void main(String[] args) throws IOException
	{
		ExcelInput[] rowArray = new ExcelInput[25];
		for(int i=0;i<25;i++)
		{
			rowArray[i]=new ExcelInput(i);
		}
		
		
		for(int i=2;i<25;i++)
		{
			int j=i;
			ExcelInput temp=rowArray[i];
			while(j>1&&temp.getCell(9).getNumericCellValue()>rowArray[j-1].getCell(9).getNumericCellValue())
			{
				rowArray[j]=rowArray[j-1];
				j--;
				
			}
			rowArray[j]=temp;
		}
		
		
		MainOutPut After=new MainOutPut();
		for(int i=0;i<25;i++)
		{
			After.SetContent(rowArray[i], i);
		}
		//����GPA��ֵ
		After.InputGPA();
		//�����Ȩƽ���ֺͼ�ȨGPA
		After.calculateScore();
		//��Afterд������
		try
		{
			After.OutPut();	
		} catch (IOException e1)
		{
			// TODO �Զ����ɵ� catch ��
			e1.printStackTrace();
		}
		System.exit(0);
	}
	}
