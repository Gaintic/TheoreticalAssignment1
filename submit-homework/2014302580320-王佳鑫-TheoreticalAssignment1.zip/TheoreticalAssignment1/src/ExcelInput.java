import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;




public class ExcelInput {
	private HSSFWorkbook workbook;  //excel�ļ�
	
	private HSSFSheet sheet;//sheetҳ
	
	private HSSFRow row; 
	
	private HSSFCell[] content; 
	
	private FileInputStream is;

	public HSSFCell getCell(int i)
	{
		return content[i];
	}
	
	public HSSFRow getRow()
	{
		return row;
	}

	public ExcelInput(int rowNumber) throws IOException
	{
		is = new FileInputStream("Marks.xls");
		content=new HSSFCell[10];
		workbook = new HSSFWorkbook(is);
		sheet = workbook.getSheet("Sheet1");
		row = sheet.getRow(rowNumber);
		for(int i=0;i<10;i++)
		{
			content[i] = row.getCell(i);
		}
	}
}
	
	
	
	//��������Ϊ�տ�ʼ����ʱ��ɵĹ��ܣ�����������������ʾ��ȡ��Excel�ļ��е����ݣ�����ҵ����ɲ�û��ʲô���ã��������ɾ������
	/*@SuppressWarnings({ "resource", "unused" })
	public static void readExcel() {
		
		try {
			InputStream is=new FileInputStream("Marks.xls");
			
			try {
				HSSFWorkbook workbook=new HSSFWorkbook(is);
				HSSFSheet sheet=workbook.getSheetAt(0);
				
				int rowCount=sheet.getPhysicalNumberOfRows();
				for(int i=0;i<rowCount;i++){
					HSSFRow row=sheet.getRow(i);
					int cellCount =row.getPhysicalNumberOfCells();
					for(int j=0;j<cellCount;j++){
						HSSFCell cell=row.getCell(j);
						int cellType=cell.getCellType();
						String cellValue=null;
						switch(cellType){
						case Cell.CELL_TYPE_STRING:
							cellValue=cell.getStringCellValue();
							break;
						case Cell.CELL_TYPE_NUMERIC:
							cellValue=String.valueOf(cell.getNumericCellValue());
							break;
						case Cell.CELL_TYPE_BLANK:
							cellValue=cell.getStringCellValue();
							break;
						case Cell.CELL_TYPE_ERROR:
							cellValue="error!";
							break;
						default:
							cellValue="error!";
						}
						System.out.println(cell); 
					}
					
				}
				
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
}*/