import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class MainOutPut {
   HSSFWorkbook workbook;  //excel�ļ�
	
	private HSSFSheet sheet;//sheetҳ
	
	private HSSFRow row[]; //��
	
	private double grade;//���������������Ȩƽ����
	
	private double sum;//���������ܵ�ѧ��
	
	private double gpa;//���������Ȩ����
	
	//������
	public HSSFRow getRow(int rowNum)
	{
		return row[rowNum];
	}
	
	//��GPA��ֵ�������
	public void InputGPA()
	{
		for(int i=0;i<25;i++)
		{
			if(i==0)
			{
				this.getRow(i).getCell(10).setCellValue("GPA");
			}
			else
			{
				double grade=this.getRow(i).getCell(9).getNumericCellValue();
				double GPA=0;
				
				boolean g1=(grade>=90);
				boolean g2=(grade<90&&grade>=85);
				boolean g3=(grade<85&&grade>=82);
				boolean g4=(grade<82&&grade>=78);
				boolean g5=(grade<78&&grade>=75);
				boolean g6=(grade<75&&grade>=72);
				boolean g7=(grade<72&&grade>=68);
				boolean g8=(grade<68&&grade>=65);
				boolean g9=(grade<65&&grade>=60);
				boolean g10=(grade<60);
				
				if(g1)GPA=4.0;
				else if(g2)GPA=3.7;
					else if(g3)GPA=3.3;
						else if(g4)GPA=3.0;
							else if(g5)GPA=2.7;
								else if(g6)GPA=2.3;
									else if(g7)GPA=2.0;
										else if(g8)GPA=1.5;
											else if(g9)GPA=1.0;
												else if(g10)GPA=0;
				
				this.getRow(i).getCell(10).setCellValue(GPA);
			}
		}
	}
	
	//�����Ȩƽ���ֺͼ�ȨGPA
	public void calculateScore()
	{
		for(int i=1;i<25;i++)
		{
			sum+=this.getRow(i).getCell(3).getNumericCellValue();
			grade+=this.getRow(i).getCell(3).getNumericCellValue()*this.getRow(i).getCell(9).getNumericCellValue();
			gpa+=this.getRow(i).getCell(3).getNumericCellValue()*this.getRow(i).getCell(10).getNumericCellValue();
			if(i==24)
			{
				this.getRow(i+1).getCell(9).setCellValue(grade/sum);
				this.getRow(i+1).getCell(10).setCellValue(gpa/sum);
			}
		}
	}
	
	public void SetContent(ExcelInput marks,int rowNumber)
	{
		
		if(rowNumber==0)
		{
			for(int i=0;i<10;i++)
			{
			row[rowNumber].getCell(i).setCellValue(marks.getCell(i).getStringCellValue());
			}
		}
		
		if(rowNumber>0)
		{
			for(int i=0;i<10;i++)
			{
			
				if(i==1|i==2|i==4|i==5|i==6|i==8)
				{
				
					row[rowNumber].getCell(i).setCellValue(marks.getCell(i).getStringCellValue());
			
				}
				else if(i==0|i==3|i==7|i==9)
				{
					row[rowNumber].getCell(i).setCellValue(marks.getCell(i).getNumericCellValue());
				}
			}
		}
	
	}
	
	
	public void OutPut() throws IOException
	{
		FileOutputStream writeFile = new FileOutputStream("After.xls");
		workbook.write(writeFile);
		writeFile.close();
	}
	
	
	public MainOutPut()
	{
		grade=0;
		sum=0;
		row=new HSSFRow[26];
		workbook = new HSSFWorkbook();
		sheet = workbook.createSheet("marks");
		for(int i=0;i<26;i++)
		{
			row[i]=sheet.createRow(i);
		}
		for(int i=0;i<26;i++)
		{
			for(int j=0;j<11;j++)
			{
				row[i].createCell(j);
			}
		}
		
	}
}
